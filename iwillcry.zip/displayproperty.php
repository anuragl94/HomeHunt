<!DOCTYPE HTML>
<html>
<head>
	 <title>HomeHunt</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/cosmo.bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrapaddon.css">
	<link rel="shortcut icon" href="images/icon2.png">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body>

<?php
include('config.php');
include('navbar.php');
$userid=$_SESSION['userid'];
$connect = mysql_connect("$db_host","$db_username","$db_password","$db_name") or die("Couldn't connect!");
	mysql_select_db("$db_name") or die("DataBase not found!");
	
	$query = mysql_query("SELECT * FROM property WHERE User_ID = '$userid'");
	echo $query;
	$result = mysql_num_rows($query);

echo "<h2>Your Input:</h2>";
if($result!=0)
{
echo '<div class="container">
		<div class="jumbotron">
		  <h1>HomeHunt</h1>		
		  <p>Details of the property you just uploaded</p>';
echo '<div class="row"><div class="col-md-2"><p>User_ID='.$row['User_ID'].'</p></div></div>';
echo '<div class="row"><div class="col-md-2"><p>Area='.$row['Area'].'</p></div></div>';
echo '<div class="row"><div class="col-md-2"><p>City='.$row['City'].'</p></div></div>';
echo '<div class="row"><div class="col-md-2"><p>Number of rooms='.$row['NoOfRooms'].'</p></div></div>';
echo '<div class="row"><div class="col-md-2"><p>Quoted Price='.$row['QuotedPrice'].'</p></div></div>';
echo '<div class="row"><div class="col-md-2"><p>Property Name='.$row['PropertyName'].'</p></div></div>';
echo '<div class="row"><div class="col-md-2"><p>Zipcode='.$row['Zipcode'].'</p></div></div>';
echo '<div class="row"><div class="col-md-2"><p>House number='.$row['HouseNo'].'</p></div></div>';
echo '<div class="row"><div class="col-md-2"><p>Street number='.$row['StreetNo'].'</p></div></div>';
echo '<div class="row"><div class="col-md-2"><p>Property is Up for:'.$row['PropertyUpFor'].'</p></div></div>';
echo '<div class="row"><div class="col-md-2"><p>QuotedPrice='.$row['QuotedPrice'].'</p></div></div>';
echo '<p>Image Uploaded:<br></br><img src="'.$row['location'].'"></p>';

}
else
	echo '<div class="row"><div class="col-md-2"><p>Problem displaying data</p></div></div>';
echo '</div></div>';

?>
</body>
</html>
