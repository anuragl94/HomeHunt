<html>
<head>
	 <title>HomeHunt</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/cosmo.bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrapaddon.css">
	<link rel="shortcut icon" href="images/icon2.png">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</head>

<body>
<?php
include('navbar.php');
//include('login_backend.php');
$areaErr = $cityErr = $numErr = $quoteErr = $zipErr = $propertyErr = $housenumErr = $streetErr = $upforErr = $imageErr = $location = "";
$Area = $City = $NoOfRooms = $QuotedPrice =$PropertyName = $Zipcode = $HouseNo = $StreetNo = $PropertyUpFor = $image = "";

?>

<div class="container">
		<div class="jumbotron">
		  <h1>HomeHunt</h1>		
		  <p>Please upload details of the property you want to advertise</p>
		  
	<br>
	<div class="container">
	<form  method="post" action="buffer.php">
		<div class="row">
			<div class="col-md-2">
			<p>Area: 
			</div>
			<div class="col-md-3">
			<input type="text" name="Area">
			<span class="error">* <?php echo $areaErr;?>
			</p>
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-2">
		<p>City: 
			</div>
			<div class="col-md-3">
		<input type="text" name="City">
		<span class="error">* <?php echo $cityErr;?></span>
		</p> 
			</div>
		</div>
		<div class="row">
			<div class="col-md-2">
		<p>Number of Rooms: 
			</div>
			<div class="col-md-3">
		<input type="text" name="NoOfRooms">
		<span class="error">* <?php echo $numErr;?></span>
		</p> 
			</div>
		</div>
		<div class="row">
			<div class="col-md-2">
		<p>Quoted Price: 
			</div>
			<div class="col-md-3">
		<input type="text" name="QuotedPrice">
		<span class="error">* <?php echo $quoteErr;?></span>
		</p> 
			</div>
		</div>
		<div class="row">
			<div class="col-md-2">
		<p>Property Name: 
			</div>
			<div class="col-md-3">
		<input type="text" name="PropertyName">
		<span class="error">* <?php echo $propertyErr;?></span>
		</p> 
			</div>
		</div>
		<div class="row">
			<div class="col-md-2">
		<p>Zipcode: 
			</div>
			<div class="col-md-3">
		<input type="text" name="Zipcode">
		<span class="error">* <?php echo $zipErr;?></span>
		</p> 
			</div>
		</div>
		<div class="row">
			<div class="col-md-2">
		<p>House Number: 
			</div>
			<div class="col-md-3">
		<input type="text" name="HouseNo">
		<span class="error">* <?php echo $housenumErr;?></span>
		</p> 
			</div>
		</div>
		<div class="row">
			<div class="col-md-2">
		<p>Street Number: 
			</div>
			<div class="col-md-3">
		<input type="text" name="StreetNo">
		<span class="error">* <?php echo $streetErr;?></span>
		</p> 
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-2">
		<p>Property Is Up For: 
			</div>
			<div class="col-md-3">
		<input type="radio" name="PropertyUpFor" <?php if (isset($PropertyUpFor) && $PropertyUpFor=="Sale") echo "checked";?>  value="Sale">Sale
        <input type="radio" name="PropertyUpFor" <?php if (isset($PropertyUpFor) && $PropertyUpFor=="Rent") echo "checked";?>  value="Rent">Rent
        <span class="error">* <?php echo $upforErr;?></span>
		</p>
		</div>
		</div>
		
		<div class="row">
			<div class="col-md-2">
		<p>Select Image: 
			</div>
			<div class="col-md-3">
		<input type="file" name="image" class="ed">
		</p> 
			</div>
		</div>
	<input type="submit" value="Submit" onsubmit='buffer.php'>
	</form>
	</div>
		</div>
	 </div>

</body>
</html>
