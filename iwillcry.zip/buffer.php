<?php
   if(isset($_POST['submit']))
   {
     header('Location: validate.php');
   }
   else
    echo 'upload not done to db';
?>