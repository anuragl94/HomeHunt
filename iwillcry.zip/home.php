<!DOCTYPE html>

<html>
  <head>
	 <title>Welcome to HomeHunt</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/cosmo.bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrapaddon.css">
	<link rel="shortcut icon" href="images/icon2.png">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
	</head>

  <body>
  <div class="dimmer">
  <?php
  include_once("navbar.php");
  ?>
	<br><br><br>
	 <div class="container">
		<div class="jumbotron">
		<h1>HomeHunt</h1>
		<p>
		
		</p>
		<p><em>"You've got to start working on the customer experience first and work back toward the technology - not the other way around."</em> - Steve Jobs</p>
		</div>
	 </div>
	</div>
	</body>
</html>