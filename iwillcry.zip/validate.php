 <!DOCTYPE HTML>
<html>
<head>
	 <title>HomeHunt</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/cosmo.bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrapaddon.css">
	<link rel="shortcut icon" href="images/icon2.png">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
	</head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body>

<?php
include('config.php'); //contains the connection to the database homehunt.sql
include('navbar.php');
//include('login_backend.php);
// define variables and set to empty values
$userErr = $areaErr = $cityErr = $numErr = $quoteErr = $zipErr = $propertyErr = $housenumErr = $streetErr = $upforErr = $imageErr = $location = "";
$User_ID = $Area = $City = $NoOfRooms = $QuotedPrice =$PropertyName = $Zipcode = $HouseNo = $StreetNo = $PropertyUpFor = $image = "";
$User_ID=$_SESSION['userid'];

   if (empty($User_ID)) {
     $userErr = "Please login";
   } 
   
   if (empty($_POST["Area"])) {
     $areaErr = "Please enter the required area";
   } else {
     $Area = test_input($_POST["Area"]);
     }
 

   if (empty($_POST["City"])) {
     $cityErr = "Please enter the required city";
   } else {
     $City = test_input($_POST["City"]);
     }


   if (empty($_POST["NoOfRooms"])) {
     $nameErr = "Number of rooms required";
   } else {
     $NoOfRooms = test_input($_POST["NoOfRooms"]);
     // check if name only digits
     if (!preg_match("/^[0-9]*$/",$NoOfRooms)) {
       $numErr = "Please enter valid numerical value";
     }
   }


   if (empty($_POST["QuotedPrice"])) {
     $quoteErr = "Enter quoted price";
   } else {
     $QuotedPrice = test_input($_POST["QuotedPrice"]);
     // check if name only digits
     if (!preg_match("/^[0-9]*$/",$QuotedPrice)) {
       $quoteErr = "Please enter valid numerical value";
     
     }
   }


   if (empty($_POST["PropertyName"])) {
     $propertyErr = "Please enter the required property name";
   } else {
     $PropertyName = test_input($_POST["PropertyName"]);
     }
   

 

   if (empty($_POST["Zipcode"])) {
     $zipErr = "Enter valid zipcode";
   } else {
     $Zipcode = test_input($_POST["Zipcode"]);
     // check if zipcode has only digits
     if (!preg_match("/^[0-9]*$/",$Zipcode)) {
       $zipErr = "Please enter valid zipcode consisting of 6 digits";
     
     }
   }



   if (empty($_POST["HouseNo"])) {
     $housenumErr = "Enter valid House Number";
   } else {
     $HouseNumber = test_input($_POST["HouseNo"]);
     // check if housenumber has only digits
     if (!preg_match("/^[0-9]*$/",$HouseNo)) {
       $housenumErr = "Please enter valid house number consisting of digits";
     
     }
   }


   if (empty($_POST["StreetNo"])) {
     $streetErr = "Enter valid Street Number";
   } else {
     $StreetNumber = test_input($_POST["StreetNo"]);
     // check if streetnumber has only digits
     if (!preg_match("/^[0-9]*$/",$StreetNo)) {
       $streetErr = "Please enter valid house number consisting of digits";
     
     }
   }

 
  if (empty($_POST["PropertyUpFor"])) {
     $upforErr = "Please indicate the required option";
   } 
   else {
     $PropertyUpFor = test_input($_POST["PropertyUpFor"]);
   }



if (!isset($_FILES['image']['tmp_name'])) {
	echo "Please enter valid image location";
	}
	else{
	$file=$_FILES['image']['tmp_name'];
	$image= addslashes(file_get_contents($_FILES['image']['tmp_name']));
	$image_name= addslashes($_FILES['image']['name']);
			
			move_uploaded_file($_FILES["image"]["tmp_name"],"photos/" . $_FILES["image"]["name"]);
			
			$location="photos/" . $_FILES["image"]["name"];
			
	}
function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
 $query=mysql_query("INSERT INTO property (Property_ID,User_ID, Area,City,NoOfRooms,QuotedPrice,PropertyName,Zipcode,HouseNo,StreetNo,Image,PropertyUpFor) VALUES ('','$User_ID', '$Area','$City','$NoOfRooms','$QuotedPrice','$PropertyName','$Zipcode','$HouseNo','$StreetNo','$location','$PropertyUpFor')");
			echo $query;
			header("location: displayproperty.php");
			//echo "Insertion done" ;
			//exit();			

?>
</body>
</html>